const e="erp",r="tree",a="normal",n="innerTable",t="tab",b=6,o="erpSubTable";export{o as E,r as a,a as e,n,b as o,e as s,t};
