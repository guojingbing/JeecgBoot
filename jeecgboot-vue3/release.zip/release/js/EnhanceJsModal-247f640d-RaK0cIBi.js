import{d as q,f as g,r as D,a2 as Q,a3 as W,a4 as b,U as m,a5 as C,af as w,ai as s,k as l,G as k,V as N}from"./vue-vendor-B4RMrPpJ.js";import{B as z}from"./index-QBPe91fh.js";import"./index-BKMXkGPq.js";import{J as L}from"./useOnlineTest-e4bd8be3-Z2g0ys0e.js";import{E as X,u as Y}from"./EnhanceJsHistory-9c4acdaf-KjU4KzHk.js";import{q as Z,b as ee}from"./enhance.api-138e6826-DRXCO_Yo.js";import{u as te,ad as se,ae,ct as ie}from"./index-BRmwJv9-.js";import{bz as oe,T as le}from"./antd-vue-vendor-D8gbVXzi.js";import re from"./JCodeEditor-xu2vz2uv.js";import"./BasicModal-Cd9Ff9-R.js";import"./useWindowSizeFn-ODKV-Zmh.js";import"./vxe-table-vendor-CoBwGrmW.js";import"./useForm-irJeawzy.js";import"./componentMap-D6GwT9mb.js";import"./useFormItem-ChoBulr_.js";import"./download-BFg9VXHr.js";import"./base64Conver-24EVOS6V.js";import"./index-RucJ9jUN.js";import"./index-Dh1R2820.js";import"./useCountdown-O4Dv84C1.js";import"./useFormItemSingle-Dj1KpT07.js";import"./JSelectUser-BtACvH7c.js";import"./props-BbyYzL_G.js";import"./JSelectBiz-yjGlVBmA.js";import"./JAddInput-hF8BxZQM.js";import"./areaDataUtil-Bs0OigMn.js";import"./china-area-data-vendor-BO18I7Ii.js";import"./index--XV8joUZ.js";import"./index-CcANhn4u.js";import"./bem-CK7R8GjU.js";import"./props-Dh_l1lvv.js";import"./useContextMenu-Cw8iOZ4D.js";import"./depart.api-DvBkjzLb.js";import"./JSelectDept-_jgSIsAx.js";import"./JPopup-BlfzMH-u.js";import"./JEllipsis-DD9hth5w.js";import"./JUpload-LWE21XIl.js";import"./index-Dd3byo2O.js";import"./index-BfmxaV2o.js";import"./index-BVrs3PDJ.js";import"./JAreaLinkage-CWoWFhfn.js";import"./EasyCronInput-rFaRqWgq.js";import"./htmlmixed-47OaOuPL.js";import"./vue-BQ8p86kv.js";/* empty css             */var S=(e,a,c)=>new Promise((f,x)=>{var i=o=>{try{u(c.next(o))}catch(n){x(n)}},r=o=>{try{u(c.throw(o))}catch(n){x(n)}},u=o=>o.done?f(o.value):Promise.resolve(o.value).then(i,r);u((c=c.apply(e,a)).next())});const V={list:[{text:".acceptHrefParams",displayText:"acceptHrefParams",superiors:"this",desc:"获取地址栏上的条件"},{text:".currentPage",displayText:"currentPage",superiors:"this",desc:"获取当前页数，默认1"},{text:".currentTableName",displayText:"currentTableName",desc:"获取当前表名"},{text:".description",displayText:"description",superiors:"this",desc:"获取当前表描述"},{text:".hasChildrenField",displayText:"hasChildrenField",superiors:"this",desc:"如果是树形列表，获取是否有子节点字段名"},{text:".ID",displayText:"ID",superiors:"this",desc:"获取当前表的配置ID"},{text:".pageSize",displayText:"pageSize",superiors:"this",desc:"获取当前每页条数，默认10"},{text:".queryParam",displayText:"queryParam",superiors:"this",desc:"获取查询表单的查询条件"},{text:".selectedRowKeys",displayText:"selectedRowKeys",superiors:"this",desc:"获取选中行的id的数组"},{text:".selectedRows",displayText:"selectedRows",superiors:"this",desc:"获取选中行的数据数组"},{text:".sortField",displayText:"sortField",superiors:"this",desc:"获取排序字段，默认‘id’"},{text:".sortType",displayText:"sortType",superiors:"this",desc:"获取排序类型，默认升序‘asc’"},{text:".total",displayText:"total",superiors:"this",desc:"获取总条数"},{text:".loadData()",displayText:"loadData()",superiors:"this",desc:"加载数据"},{text:".clearSelectedRow()",displayText:"clearSelectedRow()",superiors:"this",desc:"清除选中的行"},{text:".getLoadDataParams()",displayText:"getLoadDataParams()",superiors:"this",desc:"获取所有的查询条件，返回一个对象，包括：查询表单，高级查询，地址栏参数，分页信息，排序信息等"},{text:".isTree()",displayText:"isTree()",superiors:"this",desc:"判断当前表是不是树，返回布尔值"},{text:`beforeEdit(row){
  return new Promise((resolve, reject) => {
    if(row.字段名 == '字段值'){
      reject('测试~');
    }else{
      resolve();
    }
  })     
}`,displayText:"beforeEdit(row){}",desc:"点击操作列下的编辑按钮触发，返回promise对象"},{text:`beforeDelete(row){
	return new Promise((resolve, reject) => {
  	if(row.字段名 == '字段值'){
    	reject('测试~');
    }else{
    	resolve();
    }
  })     
}`,displayText:"beforeDelete(row){}",desc:"点击操作列下的删除按钮触发，返回promise对象"},{text:"console.log()",displayText:"console.log()",desc:"打印日志"}],form:[{text:".loading",displayText:"loading",superiors:"this",desc:"是否加载中，返回的是一个ref对象"},{text:".isUpdate",displayText:"isUpdate",superiors:"this",desc:"是否是编辑页面，返回的是一个ref对象"},{text:".onlineFormRef",displayText:"onlineFormRef",superiors:"this",desc:"主表/单表表单的ref对象"},{text:".refMap",displayText:"refMap",superiors:"this",desc:"子表表单/子表table的ref对象map，key为子表表名"},{text:".subActiveKey",displayText:"subActiveKey",desc:"子表的激活的tab索引值对应的字符串，从‘0’开始，返回的是一个ref对象"},{text:".sh",displayText:"sh",superiors:"this",desc:"单表/主表字段的显示隐藏状态"},{text:".submitFlowFlag",displayText:"submitFlowFlag",superiors:"this",desc:"是否提交表单后自动提交流程，返回一个ref对象"},{text:".subFormHeight",displayText:"subFormHeight",superiors:"this",desc:"一对一子表表单的高度，不需要设置，返回一个ref对象"},{text:".subTableHeight",displayText:"subTableHeight",superiors:"this",desc:"一对多子表table的高度，不需要设置，返回一个ref对象"},{text:".tableName",displayText:"tableName",superiors:"this",desc:"当前表名，返回的是一个ref对象"},{text:".$nextTick",displayText:"$nextTick",superiors:"this",desc:"调用的是vue3的nextTick"},{text:".字段名_load",displayText:"字段名_load",superiors:"this",desc:"控制字段的加载与否，设置为false表示当前字段不加载"},{text:".字段名_disabled",displayText:"字段名_disabled",superiors:"this",desc:"控制字段的禁用与否，设置为true表示当前字段禁用"},{text:".addSubRows(tableName, rows)",displayText:"addSubRows(tableName, rows)",superiors:"this",desc:"往一对多子表table里添加数据"},{text:".changeOptions(field, options)",texdisplayTextt:"changeOptions(field, options)",superiors:"this",desc:"改变单表/主笔 下拉控件的下拉选项"},{text:".clearSubRows(tableName)",displayText:"clearSubRows(tableName)",superiors:"this",desc:"清空一对多子表table的数据"},{text:".clearThenAddRows(tableName, rows)",displayText:"clearThenAddRows(tableName, rows)",superiors:"this",desc:"先清空一对多子表table的数据，再往里添加数据"},{text:".getFieldsValue()",displayText:"getFieldsValue()",superiors:"this",desc:"获取主表/单表 所有字段的值"},{text:".getSubTableInstance(tableName)",displayText:"getSubTableInstance(tableName)",superiors:"this",desc:"获取子表的实例对象，这个对象可以调用子表table的方法"},{text:".setFieldsValue(row)",displayText:"setFieldsValue(row)",superiors:"this",desc:"设置主表/单表 字段的值"},{text:".triggleChangeValues(values,id,target)",displayText:"triggleChangeValues(values,id,target)",superiors:"this",desc:"改变单表/主表/子表 字段的值，一般用于change事件，其中id，target需要通过change事件的内置参数获取，如果不传id，target的值，则改变的是主表的字段"},{text:".triggleChangeValue(field, value)",displayText:"triggleChangeValue(field, value)",superiors:"this",desc:"设置单表/主表 字段的值"},{text:".onlineFormValueChange(field, value, otherValus)",displayText:"onlineFormValueChange(field, value, otherValus)",superiors:"this",desc:"定义后，当表单值改变的时候会触发该方法（因js增强hook方式不支持原来的onlChange，所以定义此方法）"},{text:".changeSubTableOptions(tableName，field，options)",displayText:"changeSubTableOptions(tableName，field，options)",superiors:"this",desc:"改变一对一子表下拉框options"},{text:".changeSubFormbleOptions(tableName，field，options)",displayText:"changeSubFormbleOptions(tableName，field，options)",superiors:"this",desc:"改变一对多子表下拉框options"},{text:".changeRemoteOptions({ field, dict, label, type?, subTableName? })",displayText:"changeRemoteOptions({ field, dict, label, type?, subTableName? })",superiors:"this",desc:"改变动态下拉框options"},{text:`beforeSubmit(row){
	return new Promise((resolve, reject)=>{
    //此处模拟等待时间，可能需要发起请求
    setTimeout(()=>{
      if(row.字段名 == '字段值'){
        // 当某个字段不满足要求的时候可以reject 
        reject('测试~');
      }else{
        resolve();
      }
    },3000)
  })
}`,displayText:"beforeSubmit(row){}",desc:"提交前置事件"},{text:`loaded(){
  this.$nextTick(()=>{
    // let text = '测试js增强设置默认值';
    // if(this.isUpdate.value === true){
    //   text = '测试js增强修改表单值';
    // }
    this.setFieldsValue({
      字段名: 修改的值
    })
  })
}`,displayText:"loaded(){}",desc:"表单加载事件"},{text:`onlChange(){
  return {
    字段名(){
      let value = event.value
      console.log(value)
      this.triggleChangeValues({'字段名': '修改后的值'})
    }
  }
 }`,displayText:"onlChange(){}",desc:"单表#表单值改变事件"},{text:`子表名_onlChange(){
  return {
    字段名(){
      let value = event.value;
      console.log(value);
      let row = {'字段名': '测试一对多值改变：'+value};
      this.triggleChangeValues(row, event.row.id, event.target)
  }
  }
}`,displayText:"子表名_onlChange(){}",desc:"子表#表单值改变事件"},{text:`子表名_onlChange(){
  return {
    子表字段01(){
      this.getSubTableInstance('子表名').getValues((err,values)=>{
        this.triggleChangeValues({'主表字段名': '修改后的值'})
      }) 
    },
  }
}
`,displayText:"子表名_onlChange(){}",desc:"子改主#表单值改变事件"},{text:`onlChange(){
  return {
    字段名01(){
      let value = event.value
      this.changeOptions('字段名02', '修改后的值');
    }
    字段名02(){
      let value = event.value
      this.changeOptions('字段名03', '修改后的值');
    }
  }
}`,displayText:"changeOptions()",desc:"js增强实现下拉联动"},{text:`getAction('请求url', { 'key': 'value'}).then(res => {
  console.log(res)
})`,displayText:"getAction(url, param)",desc:"get请求"},{text:`postAction('请求url', { 'key': 'value'}).then(res => {
  console.log(res)
})`,displayText:"postAction(url, param)",desc:"post请求"},{text:`putAction('请求url', { 'key': 'value'}).then(res => {
  console.log(res)
})`,displayText:"putAction(url, param)",desc:"put请求"},{text:`deleteAction('请求url', { 'key': 'value'}).then(res => {
  console.log(res)
})`,displayText:"deleteAction(url, param)",desc:"delete请求"},{text:"console.log()",displayText:"console.log()",desc:"打印日志"}],common:[{text:"this",displayText:"this",desc:"上下文"},{text:".openCustomModal({title,width,row,formComponent,requestUrl,hide,show})",displayText:"openCustomModal({title,width,row,formComponent,requestUrl,hide,show})",desc:"打开一个弹窗-参考 Js增强打开自定义弹窗"}]},ne=q({name:"EnhanceJs",components:{BasicModal:z,JCodeEditor:re,EnhanceJsHistory:X,QuestionCircleOutlined:oe,Tooltip:le},emits:["register"],setup(){const{createMessage:e}=te(),a=Y(),c=g(),f=g(),x=D({form:{},list:{}}),i=g("list"),r=g(""),u=g(!1),o=g(!1),n=g(""),y=D({form:"",list:""}),p={form:!1,list:!1},T=g(!1),J=[...V.list,...V.common],F=[...V.form,...V.common],[h,{closeModal:M}]=se(t=>S(this,null,function*(){K(t.row)})),[H,P]=ae(),{aiTestMode:A,genEnhanceJsData:_}=L();function K(t){r.value=t.id,o.value=!1,n.value=t.tableName;let d=a.getEnhanceJs(r.value);(d==null?void 0:d.length)>0?(i.value=d[d.length-1].type,u.value=!0):u.value=!1,p.form=!1,p.list=!1,i.value?j(i.value):j("form"),T.value=!0,setTimeout(()=>T.value=!1,150)}function I(){return S(this,null,function*(){yield Promise.all([E("form"),E("list")]),M(),e.success("保存成功")})}function E(t){return S(this,null,function*(){let d=x[t],v={cgJs:y[t],cgJsType:t};if(!p[t]||d.cgJs===v.cgJs)return;let O=!!d.id;O&&(v=Object.assign({},d,v)),yield Z(r.value,v,O),a.addEnhanceJs({code:r.value,str:v.cgJs,type:v.cgJsType,date:new Date().getTime()})})}function B(){M()}function j(t){return S(this,null,function*(){i.value=t;try{if(!p[t]){let d=yield ee(r.value,t);Object.assign(x[t],{id:null},d),y[t]=x[t].cgJs,p[t]=!0}}catch(d){}setTimeout(()=>{t=="list"?f.value.refresh():c.value.refresh()},150)})}function U(){P.openModal(!0,{code:r.value,type:i.value})}function $(t){y[i.value]!=t&&(o.value=!0,y[i.value]=t)}function G(){i.value==="form"?_(n.value,i.value,c.value):_(n.value,i.value,f.value)}return{formEditorRef:c,listEditorRef:f,reloading:T,enhanceValues:y,enhanceType:i,showHistory:u,aiTestMode:A,tableName:n,genEnhanceJsData:_,onGenTestData:G,onChangeType:j,onCodeChange:$,onShowHistory:U,onSubmit:I,onCancel:B,registerModal:h,registerEnhanceJsHistory:H,listKeyWords:J,formKeyWords:F,handleGo:t=>{window.open(`https://help.jeecg.com/online/enhanceJs/${t}.html`)}}}}),R=e=>(Q("data-v-f6eb0967"),e=e(),W(),e),de={class:"titleBox"},ue=R(()=>b("span",{class:"title"},"form",-1)),pe=R(()=>b("span",null,"表单js增强文档",-1)),ce={class:"titleBox"},he=R(()=>b("span",{class:"title"},"list",-1)),me=R(()=>b("span",null,"列表js增强文档",-1));function ge(e,a,c,f,x,i){const r=m("QuestionCircleOutlined"),u=m("Tooltip"),o=m("JCodeEditor"),n=m("a-tab-pane"),y=m("a-tabs"),p=m("a-button"),T=m("a-space"),J=m("EnhanceJsHistory"),F=m("BasicModal");return C(),w(F,{onRegister:e.registerModal,title:"JS增强",width:800,bodyStyle:{height:"360px"}},{footer:s(()=>[l(T,null,{default:s(()=>[l(p,{onClick:e.onCancel},{default:s(()=>[k("关闭")]),_:1},8,["onClick"]),l(p,{type:"primary",onClick:e.onSubmit},{default:s(()=>[k("确定")]),_:1},8,["onClick"])]),_:1}),l(T,{style:{float:"left"}},{default:s(()=>[e.showHistory?(C(),w(p,{key:0,onClick:e.onShowHistory},{default:s(()=>[k("查看历史版本")]),_:1},8,["onClick"])):N("",!0),e.aiTestMode?(C(),w(p,{key:1,onClick:e.onGenTestData},{default:s(()=>[k("生成测试数据")]),_:1},8,["onClick"])):N("",!0)]),_:1})]),default:s(()=>[l(y,{activeKey:e.enhanceType,"onUpdate:activeKey":a[4]||(a[4]=h=>e.enhanceType=h),onChange:e.onChangeType},{default:s(()=>[l(n,{key:"form",forceRender:""},{tab:s(()=>[b("div",de,[ue,l(u,null,{title:s(()=>[pe]),default:s(()=>[l(r,{onClick:a[0]||(a[0]=h=>e.handleGo("form"))})]),_:1})])]),default:s(()=>[!e.reloading&&e.enhanceType==="form"?(C(),w(o,{key:0,ref:"formEditorRef",value:e.enhanceValues.form,"onUpdate:value":a[1]||(a[1]=h=>e.enhanceValues.form=h),language:"javascript",fullScreen:!0,lineNumbers:!1,height:"240px","language-change":!1,onChange:e.onCodeChange,keywords:e.formKeyWords},null,8,["value","onChange","keywords"])):N("",!0)]),_:1}),l(n,{key:"list",forceRender:""},{tab:s(()=>[b("div",ce,[he,l(u,null,{title:s(()=>[me]),default:s(()=>[l(r,{onClick:a[2]||(a[2]=h=>e.handleGo("list"))})]),_:1})])]),default:s(()=>[!e.reloading&&e.enhanceType==="list"?(C(),w(o,{key:0,ref:"listEditorRef",value:e.enhanceValues.list,"onUpdate:value":a[3]||(a[3]=h=>e.enhanceValues.list=h),language:"javascript",fullScreen:!0,lineNumbers:!1,height:"240px","language-change":!1,onChange:e.onCodeChange,keywords:e.listKeyWords},null,8,["value","onChange","keywords"])):N("",!0)]),_:1})]),_:1},8,["activeKey","onChange"]),l(J,{onRegister:e.registerEnhanceJsHistory},null,8,["onRegister"])]),_:1},8,["onRegister"])}const rt=ie(ne,[["render",ge],["__scopeId","data-v-f6eb0967"]]);export{rt as default};
