import{w as t,t as s}from"./index-BRmwJv9-.js";const i=t(s);export{i as T};
