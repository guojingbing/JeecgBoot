import{d as u,f as n,r as a,o as s,a5 as i,a6 as c,a4 as p}from"./vue-vendor-B4RMrPpJ.js";import{C as m}from"./htmlmixed-47OaOuPL.js";import"./vue-BQ8p86kv.js";import{_ as d}from"./index-BRmwJv9-.js";import"./antd-vue-vendor-D8gbVXzi.js";import"./vxe-table-vendor-CoBwGrmW.js";const C=u({components:{},setup(){const r=window.CodeMirror||m,e=n(null),t=a({tabSize:2,theme:"cobalt",lineNumbers:!0,line:!0});s(()=>{o()});function o(){r.fromTextArea(e.value,t)}return{textarea:e}}}),f={ref:"textarea"};function l(r,e,t,o,_,x){return i(),c("div",null,[p("textarea",f,`\r
白日依山尽，黄河入海流。\r
欲穷千里目，更上一层楼。\r
        `,512)])}const b=d(C,[["render",l]]);export{b as default};
